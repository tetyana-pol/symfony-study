AsseticBundle
=============

The `AsseticBundle` provides integration of the [Assetic](https://github.com/kriswallsmith/assetic)
library into the Symfony2 framework.

More information in the official [documentation](https://symfony.com/doc/current/cookbook/assetic/index.html).

License
=======

This bundle is released under the [MIT license](LICENSE)
