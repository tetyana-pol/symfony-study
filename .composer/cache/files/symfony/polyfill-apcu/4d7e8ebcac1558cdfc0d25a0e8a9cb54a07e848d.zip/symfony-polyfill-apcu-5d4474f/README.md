Symfony Polyfill / APCu
========================

This component provides `apcu_*` functions and the `APCUIterator` class to users of the legacy APC extension.

More information can be found in the
[main Polyfill README](https://github.com/symfony/polyfill/blob/master/README.md).

License
=======

This library is released under the [MIT license](LICENSE).
