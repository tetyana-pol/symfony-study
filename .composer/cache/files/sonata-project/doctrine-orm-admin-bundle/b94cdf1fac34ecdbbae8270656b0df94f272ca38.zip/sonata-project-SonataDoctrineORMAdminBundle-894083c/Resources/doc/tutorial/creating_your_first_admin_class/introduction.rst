.. index::
    single: Tutorial

Introduction
============

This is a tutorial & how-to for creating your first ``Admin`` classes using the ``AdminBundle``.
In this example, we'll create the backend of a blog application.

The tutorial will explain how to define:

* Entities,
* The routing,
* CRUD controller,
* The ``Admin`` class.
