.. index::
    double: Tutorial; Routing

Defining the routing
====================

Each entity requires 6 routes:

* `list`,
* `create`,
* `batch`,
* `update`,
* `edit`,
* `delete`.

The route information is automatically generated for you, so you can jump straight into the next chapter.
