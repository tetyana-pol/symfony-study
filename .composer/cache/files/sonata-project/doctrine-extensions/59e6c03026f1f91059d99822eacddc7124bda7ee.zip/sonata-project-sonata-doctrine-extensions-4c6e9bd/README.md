Sonata Doctrine Extensions
==========================

[![Build Status](https://secure.travis-ci.org/sonata-project/doctrine-extensions.png?branch=master)](http://travis-ci.org/sonata-project/doctrine-extensions)

### Installation using Composer

Add the dependency:

```bash
php composer.phar require sonata-project/doctrine-extensions
```

If asked for a version, type in 'dev-master' (unless you want another version):

```bash
Please provide a version constraint for the sonata-project/doctrine-extensions requirement: dev-master
```

### Doctrine Types

  - JsonType

### Google Groups

For questions and proposals you can post on this google groups

* [Sonata Users](https://groups.google.com/group/sonata-users): Only for user questions
* [Sonata Devs](https://groups.google.com/group/sonata-devs): Only for devs
