<?php

namespace Application\Sonata;

class NotExtendableBundle extends \Symfony\Component\HttpKernel\Bundle\Bundle
{
}
