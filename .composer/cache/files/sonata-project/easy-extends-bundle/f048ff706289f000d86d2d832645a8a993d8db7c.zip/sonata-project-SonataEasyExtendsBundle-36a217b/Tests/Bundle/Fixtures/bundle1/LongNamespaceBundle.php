<?php

namespace Sonata\Bundle\AcmeBundle;

class LongNamespaceBundle extends \Symfony\Component\HttpKernel\Bundle\Bundle
{
}
