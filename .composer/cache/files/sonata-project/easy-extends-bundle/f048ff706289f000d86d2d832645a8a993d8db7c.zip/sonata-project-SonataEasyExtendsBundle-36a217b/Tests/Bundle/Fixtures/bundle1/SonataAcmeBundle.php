<?php

namespace Sonata\AcmeBundle;

class SonataAcmeBundle extends \Symfony\Component\HttpKernel\Bundle\Bundle
{
    public function getPath()
    {
        return __DIR__;
    }
}
