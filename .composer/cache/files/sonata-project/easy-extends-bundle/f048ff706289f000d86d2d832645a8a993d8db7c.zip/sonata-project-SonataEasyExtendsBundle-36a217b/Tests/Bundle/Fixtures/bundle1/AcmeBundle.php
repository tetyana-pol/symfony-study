<?php

namespace Sonata\AcmeBundle;

class AcmeBundle extends \Symfony\Component\HttpKernel\Bundle\Bundle
{
}
