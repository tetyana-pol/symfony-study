<?php

namespace Symfony\Bundle;

class NotExtendableBundle extends \Symfony\Component\HttpKernel\Bundle\Bundle
{
}
